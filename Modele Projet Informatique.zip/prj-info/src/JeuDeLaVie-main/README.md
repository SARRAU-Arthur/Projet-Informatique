# Jeu de la vie. 
Le jeu de la vie est un projet de 2ème année de classe préparatoire à l'INSA de Rouen dans le cadre du projet informatique.
